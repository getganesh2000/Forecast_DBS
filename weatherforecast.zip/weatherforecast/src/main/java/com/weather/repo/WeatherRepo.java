package com.weather.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import com.weather.model.Forecast;

@RepositoryRestResource
public interface WeatherRepo extends CrudRepository<Forecast,Long> {
	Forecast findByCityName(String cityName);
}
