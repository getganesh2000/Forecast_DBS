package com.weather.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Optional;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.weather.model.Forecast;
import com.weather.repo.WeatherRepo;


@Component
public class WeatherForecastService {
	private static final Logger logger = LoggerFactory.getLogger(WeatherForecastService.class);

	@Autowired
	WeatherRepo wr;

	public void  findWeather(String loc, String cityName ) {
		
		System.out.println("************" + cityName);

		Forecast result = wr.findByCityName(cityName);

		if (result==null) {

			String urlString = String.format("https://api.darksky.net/forecast/e46b84f36fe01b0031f5cee09b28974b" + "/%s?exclude=minutely,hourly,daily,alerts,flags&units=si", loc);
			JSONParser parser = new JSONParser();
			JSONObject json = null;
			Forecast results = null;
			System.out.println(urlString);
			try {
				URL url = new URL(urlString);
				BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
				String line;
				while ((line = reader.readLine()) != null)
				{
					json=(JSONObject)parser.parse(line);
				}
			}
			catch(Exception ex) {
				logger.info("Error from findUser"+ ex.toString());
			}

			Optional<JSONObject> elem = Optional.of((JSONObject)json.get("currently"));
			ObjectMapper mapper = new ObjectMapper();
			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			try {
				if (elem.isPresent()) results = mapper.readValue(elem.get().toJSONString(), Forecast.class);
				results.setCityName(cityName);
			}
			catch(Exception ex) {
				logger.info("Error from findUser"+ ex.toString());
			}

			System.out.println(results.getCityName());
			System.out.println(results.getTemperature());

			if(results!=null)wr.save(results);


		}
	}
}
