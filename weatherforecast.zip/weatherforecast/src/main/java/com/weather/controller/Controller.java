package com.weather.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.weather.model.Forecast;
import com.weather.repo.WeatherRepo;
import com.weather.service.WeatherForecastService;

enum longaltitude{
	
	campbel("37.2872,-121.94996"),
	omaha("41.2565,-95.9345"),
	austin("30.2672,-97.7431"),
	niseko("42.8048,140.6874"),
	nara("34.6851,135.8048"),
	jakarta("6.2088,106.8456");

	private String loc;

	longaltitude(String loc) {
		this.loc = loc;
	}

	public String loc() {
		return loc;
	}
}

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:8080")
public class Controller {
	
	@Autowired
	WeatherRepo wr;
	
	@Autowired
	WeatherForecastService wfs;
	
	@GetMapping("/weather/{cityName}")
    public Forecast getForecast(@PathVariable("cityName") String cityName){
		
		System.out.println(cityName);

		if (cityName.trim().equalsIgnoreCase("campbell")) 
			wfs.findWeather(longaltitude.campbel.loc(), cityName);
		else if (cityName.trim().equalsIgnoreCase("omaha")) wfs.findWeather(longaltitude.omaha.loc(), cityName);
		else if (cityName.trim().equalsIgnoreCase("austin")) wfs.findWeather(longaltitude.austin.loc(), cityName);
		else if (cityName.trim().equalsIgnoreCase("niseko")) wfs.findWeather(longaltitude.niseko.loc(), cityName);
		else if (cityName.trim().equalsIgnoreCase("nara")) wfs.findWeather(longaltitude.nara.loc(), cityName);
		else if (cityName.trim().equalsIgnoreCase("jakarta")) wfs.findWeather(longaltitude.jakarta.loc(), cityName);
		
		
		return (Forecast)wr.findByCityName(cityName);
    }

}
