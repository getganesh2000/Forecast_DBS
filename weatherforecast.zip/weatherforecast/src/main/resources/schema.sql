CREATE TABLE FORECAST(
  FORECAST_ID BIGINT AUTO_INCREMENT PRIMARY KEY,
  latitude VARCHAR(30),
  longitude VARCHAR(30),
  timezone VARCHAR(30) ,
  summary VARCHAR(30),
  icon VARCHAR(30) ,
  temperature double,
  humidity double,
  city_Name VARCHAR(30) NOT NULL,
  timestamp DATE
);