package com.forecast.services.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

enum longaltitude{
	
	campbel("37.2872,-121.94996"),
	omaha("41.2565,-95.9345"),
	austin("30.2672,-97.7431"),
	niseko("42.8048,140.6874"),
	nara("34.6851,135.8048"),
	jakarta("6.2088,106.8456");

	private String loc;

	longaltitude(String loc) {
		this.loc = loc;
	}

	public String loc() {
		return loc;
	}
}

@RestController
public class ForecastController {

	@Autowired
	private RestTemplate restTemplate;


	@RequestMapping(value="/weather/{cityName}",method=RequestMethod.GET)
	public Forecast getForecast(@PathVariable("cityName") String cityName){

		System.out.println(cityName);

		String theUrl = "http://forecastservices/api/weather/" + cityName ;

		ResponseEntity<Forecast> response = restTemplate.exchange(theUrl, HttpMethod.GET, null, new ParameterizedTypeReference<Forecast>() {
		});

		Forecast forecast = response.getBody();
		return forecast;
	}
}
