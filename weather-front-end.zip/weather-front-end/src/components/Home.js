import React,{Component} from 'react';
import Header from './Header.js';
import Details from './Details.js';
import CityList from './CityList.js';

class Home extends Component {
  constructor(props){
    super(props);
    this.state={
      cities:[],
      currentCity:null,
    };
    this.onRecipeClick=this.onRecipeClick.bind(this);
  }

  getCitiNames(){
    return [
    {
    "Id":"1",
    "cityName":"Campbell"
    },
    {
    "Id":"2",
    "cityName":"Omaha"
  },
  {
  "Id":"3",
  "cityName":"Austin"
},
{
"Id":"4",
"cityName":"Niseko"
},
{
"Id":"5",
"cityName":"Nara"
},
{
"Id":"6",
"cityName":"Jakarta"
},

    ]
  }


  componentDidMount(){
    this.setState({cities:this.getCitiNames()});
  }

onRecipeClick=(cityName)=>{
  fetch(`${API_URL}/${cityName}`)
  .then(res=>res.json())
  .then(details => {
    this.setState({currentCity:details});
  });
}

render(){
  const {cities,currentCity} = this.state;
  const imagePath=`../static/image/`
  return(   <div>
    <Header />
    <main style={{display: 'flex'}}>
    <CityList cities={cities} style={{flex:3}}
    onClick={this.onRecipeClick}
    />
    <Details
    details={currentCity}
    imagepath={imagePath}
    style={{flex:5}}/>
    </main>
    </div>);
}

};

export default Home;
