import React from 'react';

const CityList = (props) => (
    <div style={props.style}>
      <h2>City Names</h2>
      <ul>
        {props.cities.map(cities=>(
          <li key={cities.Id}
          onClick={()=>props.onClick(cities.cityName)}>
              <span>{cities.cityName}</span>
          </li>
        )
        )}
      </ul>
    </div>
)

export default CityList;
