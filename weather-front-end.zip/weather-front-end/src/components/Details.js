import React from 'react';

const Details = (props) => {



  if(!props.details){
    return(
      <p style={props.style}>
        pls select a recipe  to see the detail.
        </p>    );
  }

  return(
    <div style={props.style}>
    <h2>{props.details.cityName} </h2>
    <img src={require(`../static/image/${props.details.icon}.png`)}/>
      <div>
        <span>{props.details.temperature}°C</span>
      </div>
      <h3> Details</h3>
      <span>{props.details.summary}</span>
    </div>
  );

}

export default Details;
